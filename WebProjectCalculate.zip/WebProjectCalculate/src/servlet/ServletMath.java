package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MathServlet
 */
@WebServlet("/math")
public class ServletMath extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletMath() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.sendRedirect("/WebProjectCalculate/input.jsp");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int a = 0;
		int b = 0;
		int c = 0;
		int sum = 0;
		int subtraction = 0;
		
		boolean signal=true;
		
		String parametaraA = request.getParameter("a");
		try {
			if (parametaraA.isEmpty())
				throw new Exception("Insert number");
               a=Integer.parseInt(parametaraA);
               
		} catch (Exception e) {
			signal=false;
			request.setAttribute("errorA", "A is not number");
		}
		

		String parametaraB = request.getParameter("b");
		try {
			if (parametaraB.isEmpty())
				throw new Exception("Insert number");
               b=Integer.parseInt(parametaraB);
           	} catch (Exception e) {
           		signal=false;
           		request.setAttribute("errorB", "B is not number");
		}
		
		String parametarC = request.getParameter("c");
		try {
			if (parametarC.isEmpty())
				throw new Exception("Insert number");
               c=Integer.parseInt(parametarC);
           	} catch (Exception e) {
           		signal=false;
           		request.setAttribute("errorC", "C is not number");
		}
		
		if (signal) {
			if((request.getParameter("sum")!=null)) {
				sum=a+b+c;
				System.out.println("Sum = "+sum);
			}else if(request.getParameter("sub")!=null) {
				subtraction=a-b-c;
				System.out.println("Subtract = "+subtraction);
			}
			request.setAttribute("c", c);
		}else {
		request.setAttribute("errorC", "A and B are not inserted in the correct way!");
	}

		
		
		request.setAttribute("parametaraA",parametaraA );
		request.setAttribute("parametaraB", parametaraB);
		request.setAttribute("c", c);
		
		RequestDispatcher rd = request.getRequestDispatcher("./input.jsp");
		rd.forward(request, response);

	}

}
